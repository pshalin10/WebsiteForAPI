import { Component, OnInit, ViewChild } from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators
} from '@angular/forms';
import { MatButton } from '@angular/material/button';
import { MatOptionSelectionChange } from '@angular/material/core';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { Observable, of } from 'rxjs';
import {
  debounceTime,
  filter,
  finalize,
  first,
  startWith,
  switchMap,
  tap
} from 'rxjs/operators';
import { CustomerService } from 'src/app/Main/services/customer.service';
import { InvoiceService } from 'src/app/Main/services/invoice.service';
const SNACKBAR_CONFIG: MatSnackBarConfig<any> = {
  horizontalPosition: 'end',
  verticalPosition: 'top',
  duration: 3000
};

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.scss']
})
export class InvoiceComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    private invoiceService: InvoiceService,
    private customerService: CustomerService,
    private _snackBar: MatSnackBar
  ) {}
  isLoading = false;
  creatingInvoice = false;
  public invoiceForm: FormGroup = this.fb.group({
    customer_id: new FormControl(null),
    payment_method_id: new FormControl(null),
    meta: new FormGroup({
      lineItems: new FormArray([]),
      tax: new FormControl(0),
      subtotal: new FormControl('', [Validators.required])
    }),
    url: 'https://omni.fattmerchant.com/#/bill/',
    total: new FormControl('', [Validators.required]),
    send_now: new FormControl(false),
    memo: new FormControl('', [Validators.required])
  });
  filteredCustomers$:
    | Observable<any>
    | undefined = this.customerService.getCustomers();
  ngOnInit(): void {
    this.createLineItem();
    this.attachCustomerChangeHandler();
  }

  /**
   * attachCustomerChangeHandler
   */
  private attachCustomerChangeHandler() {
    this.filteredCustomers$ = this.invoiceForm
      .get('customer_id')
      ?.valueChanges.pipe(
        startWith(''),
        filter(val => typeof val === 'string'),
        switchMap((val: string) => this.customerService.getCustomers(val))
      );
  }

  customerDisplayFn(customer: any) {
    return customer && typeof customer === 'object'
      ? customer?.firstname + ' ' + customer?.lastname
      : '';
  }

  public metaForm(): FormGroup {
    return this.invoiceForm.get('meta') as FormGroup;
  }

  private resetInvoiceForm() {
    this.invoiceForm.reset();
    this.lineItems.clear();
    this.createLineItem();
    this.invoiceForm.get('memo')?.setErrors(null);
  }

  /**
   * Dynamically add line item
   */
  public createLineItem() {
    const fg = new FormGroup({
      id: new FormControl(null),
      item: new FormControl('', [Validators.required]),
      details: new FormControl('', [Validators.required]),
      quantity: new FormControl(1, [Validators.required, Validators.min(0)]),
      price: new FormControl(0, [Validators.required, Validators.min(0)])
    });
    this.lineItems.push(fg);
  }

  public totalOfIndividualLineItem(index: number): number {
    return (
      this.lineItems.at(index).get('quantity')?.value *
      this.lineItems.at(index).get('price')?.value
    );
  }

  public getFormgroupAtIndex(i: number): FormGroup {
    return this.lineItems.at(i) as FormGroup;
  }

  get getTotalAmount(): number {
    const len: number = this.lineItems.length;
    let totalAmount = 0;
    for (let i = 0; i < len; i++) {
      totalAmount += this.totalOfIndividualLineItem(i);
    }
    return totalAmount;
  }

  /**
   * Remove line item at given index
   */
  public removeLineItem(index: number): void {
    if (this.lineItems.length === 1) {
      return;
    }
    this.lineItems.removeAt(index);
  }
  /**
   * Get line items
   */
  get lineItems(): FormArray {
    return this.invoiceForm.get('meta')?.get('lineItems') as FormArray;
  }

  /**
   * Creates invoice
   * @returns : Void
   */
  public createInvoice() {
    const subTotal = this.getTotalAmount;
    const tax = this.invoiceForm.get('meta')?.get('tax')?.value;
    this.invoiceForm
      .get('meta')
      ?.get('subtotal')
      ?.patchValue(subTotal);
    this.invoiceForm.get('total')?.patchValue(subTotal + tax);

    if (this.invoiceForm.invalid) {
      this._snackBar.open(
        'Mandatory fields missing',
        undefined,
        SNACKBAR_CONFIG
      );
      return;
    }
    this.creatingInvoice = true;
    const customer_id = this.invoiceForm.get('customer_id')?.value;
    if (customer_id) {
      this.invoiceForm.get('customer_id')?.patchValue(customer_id?.id);
    }
    this.invoiceService
      .createInvoice(this.invoiceForm.value)
      .pipe(
        first(),
        finalize(() => (this.creatingInvoice = false))
      )
      .subscribe(
        (_: any) => {
          this._snackBar.open('Invoice created', undefined, SNACKBAR_CONFIG);
          this.resetInvoiceForm();
        },
        err => {
          this._snackBar.open(
            'Could not create invoice',
            undefined,
            SNACKBAR_CONFIG
          );
          console.log('error', err);
        }
      );
  }
}
