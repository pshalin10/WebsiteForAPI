import { AfterViewInit, OnDestroy } from '@angular/core';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatOptionSelectionChange } from '@angular/material/core';
import { Observable, of, Subject } from 'rxjs';
import {
  debounceTime,
  filter,
  finalize,
  startWith,
  switchMap,
  takeUntil,
  tap
} from 'rxjs/operators';
import { InvoiceService } from 'src/app/Main/services/invoice.service';

@Component({
  selector: 'app-line-item',
  templateUrl: './line-item.component.html',
  styleUrls: ['./line-item.component.scss']
})
export class LineItemComponent implements AfterViewInit, OnDestroy {
  @Input() lineItem!: any;
  @Input() index!: number;
  isLoading = false;
  @Input() formGroup!: FormGroup;
  filteredOptions$: Observable<any> | undefined;
  destroyed$: Subject<any> = new Subject();
  @Output() remove: EventEmitter<any> = new EventEmitter();
  constructor(private invoiceService: InvoiceService) {}
  ngAfterViewInit(): void {
    this.filteredOptions$ = this.formGroup.get('item')?.valueChanges.pipe(
      startWith(''),
      filter(val => typeof val === 'string'),
      debounceTime(300),
      tap(_ => (this.isLoading = true)),
      takeUntil(this.destroyed$),
      switchMap((val: string) => {
        return this.invoiceService.getLineItems(val).pipe(
          takeUntil(this.destroyed$),
          finalize(() => (this.isLoading = false))
        );
      })
    );
  }
  removeLineItem(): void {
    this.remove.emit();
  }

  public lineItemSelected(
    event: MatOptionSelectionChange,
    index: number,
    option: any
  ) {
    const { price, details, id } = option;
    this.lineItem.patchValue(
      {
        price,
        details,
        id
      },
      { onlySelf: true, emitEvent: false }
    );
  }

  ngOnDestroy(): void {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }
}
