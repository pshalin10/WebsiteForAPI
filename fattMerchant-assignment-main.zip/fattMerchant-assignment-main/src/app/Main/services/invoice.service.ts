import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class InvoiceService {
  constructor(private http: HttpClient) {}

  /**
   * Get line items from server
   */
  public getLineItems(keyword: string = '') {
    return this.http
      .get(`${environment.BASE_URL}/item`, {
        params: {
          'keywords[]': keyword
        }
      })
      .pipe(map((res: any) => res?.data));
  }

  /**
   * Create invoice
   */
  public createInvoice(data: any) {
    return this.http.post(`${environment.BASE_URL}/invoice`, data);
  }
}
